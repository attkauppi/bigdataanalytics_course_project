Suomen maakunnat ja kunnat
=========

Suomen maakunnat ja kunnat geoJSON-muodossa kartalla.  
  
Koordinaatit ystävällisesti tarjosi Jens Finnäs  
- http://dataist.wordpress.com/2012/12/16/finnish-regional-geodata-as-geojson-and-kml/  

Infot scrapettu Wikipediasta  
- http://fi.wikipedia.org/wiki/Suomen_maakunnat  
- http://fi.wikipedia.org/wiki/Luettelo_Suomen_kunnista  