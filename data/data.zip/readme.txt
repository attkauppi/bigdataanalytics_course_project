swissBOUNDARIES3D Kantonsgrenzen (Bundesamt f�r Landestopografie swisstopo) / swissBOUNDARIES3D limites cantonales (Office f�d�ral de topographie swisstopo) 39.3

DOWNLOADS

INTERLIS1 LV95:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/itf/2056/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

INTERLIS1 LV03:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/itf/21781/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

INTERLIS2 LV95:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/xtf/2056/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

INTERLIS2 LV03:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/xtf/21781/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

FILE GEODATABASE LV95:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/gdb/2056/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

FILE GEODATABASE LV03:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/gdb/21781/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

DXF LV95:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/dxf/2056/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

DXF LV03:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/dxf/21781/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

SHAPEFILE LV95:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/shp/2056/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip

SHAPEFILE LV03:
https://data.geo.admin.ch/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill/shp/21781/ch.swisstopo.swissboundaries3d-kanton-flaeche.fill.zip
